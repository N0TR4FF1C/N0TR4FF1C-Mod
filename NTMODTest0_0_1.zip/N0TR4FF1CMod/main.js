// ******************************************************************************************
// Mod Name: N0TR4FF1CMod
// Mod Id: N0TR4FF1CMod_NT
// Mod Version: 0.0.1
// Mod File: main.js
// ******************************************************************************************
// Author: NT
// Last modified: 31.07.2017 16:42
// ******************************************************************************************
// Notes: This file is defined in package.json and loaded as the first file from GDT
// ******************************************************************************************

// Setup a global mod object
var N0TR4FF1CMod_NT   = { modPath: '', data: {} };

(function(){
	// Acquire relative path to the mod
	N0TR4FF1CMod_NT.modPath = GDT.getRelativePath();

	// Callback executed after succesful load
	var ready = function () {
	};

// Callack executed if error(s) occured during load
	var error = function () {
	};

	// Load relevant files
	GDT.loadJs(['main/code_before.js', 'main/code.js', 'main/code_after.js'], ready, error);

})();
